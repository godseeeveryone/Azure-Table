﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;

namespace AzureBlobConsoleApp
{
    public class Program 
    {
        static async Task Main1(string[] args)
        {
            // TODO: Replace <storage-account-name> with your actual storage account name
            var blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=harishstorageaccount001;AccountKey=JqWjvSH+HFjFdUBNgEcq0SSBpQe8BhCRxDGfeBeSlnadetbz6n7lUzL0vjEz4y80aeL3e+qRjAlg+ASt5WShcw==;EndpointSuffix=core.windows.net");

            string containerName = "democontainer51";
            // Create the container and return a container client object
            BlobContainerClient containerClient = await blobServiceClient.CreateBlobContainerAsync(containerName);

            // Create a local file in the ./data/ directory for uploading and downloading
            string localPath = "E:/Azure/Azure Blob";
            string fileName = "blobDemo" + Guid.NewGuid().ToString() + ".txt";
            string localFilePath = Path.Combine(localPath, fileName);

            // Write text to the file
            await File.WriteAllTextAsync(localFilePath, "Hello, Welcome in azure demo!");

            // Get a reference to a blob
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            Console.WriteLine("Uploading to Blob storage as blob:\n\t {0}\n", blobClient.Uri);

            // Upload data from the local file
            await blobClient.UploadAsync(localFilePath, true);

            Console.WriteLine("Listing blobs...");

            // List all blobs in the container
            await foreach (BlobItem blobItem in containerClient.GetBlobsAsync())
            {
                Console.WriteLine("\t" + blobItem.Name);
            }

            // Download the blob to a local file
            // Append the string "DOWNLOADED" before the .txt extension 
            // so you can compare the files in the data directory
            string downloadFilePath = localFilePath.Replace(".txt", "DOWNLOADED.txt");

            Console.WriteLine("\nDownloading blob to\n\t{0}\n", downloadFilePath);

            // Download the blob's contents and save it to a file
            await blobClient.DownloadToAsync(downloadFilePath);

            // Clean up
            Console.Write("Press any key to begin clean up");
            Console.ReadLine();

            Console.WriteLine("Deleting blob container...");
            await containerClient.DeleteAsync();

            Console.WriteLine("Deleting the local source and downloaded files...");
            File.Delete(localFilePath);
            File.Delete(downloadFilePath);

            Console.WriteLine("Done");
        }


        static async Task Main(string[] args)
        {
            // TODO: Replace <storage-account-name> with your actual storage account name
            var blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=harishstorageaccount001;AccountKey=JqWjvSH+HFjFdUBNgEcq0SSBpQe8BhCRxDGfeBeSlnadetbz6n7lUzL0vjEz4y80aeL3e+qRjAlg+ASt5WShcw==;EndpointSuffix=core.windows.net");
           // var blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=pageblobharish;AccountKey=bdiLW30Fk/ssIjdWN/ELalZn4zbUTz1kCkSfjiEFZjHWl/tl64KS2HGI5MobtCeAG9MiW0mFX+lh+ASt+gU2hw==;EndpointSuffix=core.windows.net");
            string containerName = "container2";
            // Create the container and return a container client object
            // BlobContainerClient containerClient = await blobServiceClient.CreateBlobContainerAsync(containerName);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);

            // Create a local file in the ./data/ directory for uploading and downloading
            string localPath = "E:/Azure/Azure Blob/onemb.pdf";

            //Block Blob
            //await UploadInBlocks(containerClient, localPath, 1000000);
            //End Block Blob

            //Append Blob
            Console.WriteLine("please enter text to add to the blob: ");
            string text = Console.ReadLine();
            AppendBlobClient appendBlobClient = containerClient.GetAppendBlobClient("append.txt");
            if (!await appendBlobClient.ExistsAsync())
            {
                await appendBlobClient.CreateAsync();
            }
            using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(text)))
            {
                await appendBlobClient.AppendBlockAsync(ms);
            }
            //End Append Blob

            //Page Blob
            //await PageBlobUpload(containerClient);
            //End Page Blob
        }

        public static async Task PageBlobUpload(BlobContainerClient container)
        {
            await container.CreateIfNotExistsAsync();

            Console.WriteLine("Create Page Blob");
            PageBlobClient pageBlob = container.GetPageBlobClient("blob1");
            pageBlob.Create(5 * 512);

            Console.WriteLine("Write Pages to Blob");

            byte[] bytearry = new byte[512];
            FileStream fs = new FileStream(@"E:/Azure/Azure Blob/harishverma.txt", FileMode.Open);
            fs.Read(bytearry, 0, 512);


            using (MemoryStream memoryStream = new MemoryStream(bytearry))
            {
                await pageBlob.UploadPagesAsync(memoryStream, 512);
            }

            using (MemoryStream memoryStream = new MemoryStream(bytearry))
            {
                {
                    await pageBlob.UploadPagesAsync(memoryStream, 3 * 512);
                }

                Console.WriteLine("Get Page Ranges");
                IEnumerable<HttpRange> pageRanges = (await pageBlob.GetPageRangesAsync()).Value.PageRanges;
                foreach (HttpRange pageRange in pageRanges)
                {
                    Console.WriteLine(pageRange.ToString());
                }

                Stream blobStream = pageBlob.OpenRead();
                byte[] data = new byte[5*512];
                blobStream.Seek(0, SeekOrigin.Begin); // start reading fro 512
                blobStream.Read(data, 0, 5*512);
                File.WriteAllBytes(@"E:/Azure/Azure Blob/output.txt", data);

                // Clean up after the demo. This line is not strictly necessary as the container is deleted in the next call.
                // It is included for the purposes of the example. 
                Console.WriteLine("Delete page blob");
                await pageBlob.DeleteIfExistsAsync();
                Console.WriteLine();
            }
        }

        public static async Task UploadInBlocks
    (BlobContainerClient blobContainerClient, string localFilePath, int blockSize)
        {
            string fileName = Path.GetFileName(localFilePath);
            BlockBlobClient blobClient = blobContainerClient.GetBlockBlobClient(fileName);

            FileStream fileStream = File.OpenRead(localFilePath);

            ArrayList blockIDArrayList = new ArrayList();

            byte[] buffer;

            var bytesLeft = (fileStream.Length - fileStream.Position);

            while (bytesLeft > 0)
            {
                if (bytesLeft >= blockSize)
                {
                    buffer = new byte[blockSize];
                    await fileStream.ReadAsync(buffer, 0, blockSize);
                }
                else
                {
                    buffer = new byte[bytesLeft];
                    await fileStream.ReadAsync(buffer, 0, Convert.ToInt32(bytesLeft));
                    bytesLeft = (fileStream.Length - fileStream.Position);
                }

                using (var stream = new MemoryStream(buffer))
                {
                    string blockID = Convert.ToBase64String
                        (Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));

                    blockIDArrayList.Add(blockID);


                    await blobClient.StageBlockAsync(blockID, stream);
                }

                bytesLeft = (fileStream.Length - fileStream.Position);

            }

            string[] blockIDArray = (string[])blockIDArrayList.ToArray(typeof(string));

            await blobClient.CommitBlockListAsync(blockIDArray);
        }
    }



}
