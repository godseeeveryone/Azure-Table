﻿using Azure;
using Azure.Data.Tables;
using System;

namespace AzureTableDemo
{
    class Program
    {
        class PersonEntity : ITableEntity
        {
            public string PartitionKey { get; set; }
            public string RowKey { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string Country { get; set; }
            public DateTimeOffset? Timestamp { get; set; }
            public ETag ETag { get; set; }
        }

        static void Main(string[] args)
        {
            var connectionString = "DefaultEndpointsProtocol=https;AccountName=harishstorageaccount001;AccountKey=JqWjvSH+HFjFdUBNgEcq0SSBpQe8BhCRxDGfeBeSlnadetbz6n7lUzL0vjEz4y80aeL3e+qRjAlg+ASt5WShcw==;EndpointSuffix=core.windows.net";
            var tableName = "AzureTableDemoDb";

            var client = new TableClient(connectionString, tableName);

            // Create the table if it doesn't already exist to verify we've successfully authenticated.
            client.CreateIfNotExists();

            Console.WriteLine("Table Created, Press enter to add entity");
            Console.ReadLine();
            AddEntity(client);

            Console.WriteLine("Entry Created, Press enter to update entity");
            Console.ReadLine();
            UpdateEntity(client, "User", "1");

            Console.WriteLine("Entry Updated, Press enter to read entity");
            Console.ReadLine();
            GetPersonEntities(client, "User");

            Console.WriteLine("Entry Updated, Press enter to delete entity");
            Console.ReadLine();
            DeleteEntity(client, "User", "1");
        }

        static void AddEntity(TableClient client)
        {
            try
            {
                PersonEntity personEntity = new PersonEntity
                {
                    PartitionKey = "User",
                    RowKey = "1",
                    FirstName = "Harish",
                    LastName = "Verma",
                    City = "Pathankot",
                    State = "Punjab",
                    Country = "India"
                };
                client.AddEntity(personEntity);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                // Make a dictionary entity by defining a <see cref="TableEntity">.
                var tableEntity = new TableEntity("Product", "1")
            {
                { "Product", "Marker Set" },
                { "Price", 5.00 },
                { "Quantity", 21 }
            };
                Console.WriteLine($"{tableEntity.RowKey}: {tableEntity["Product"]} costs ${tableEntity.GetDouble("Price")}.");
                client.AddEntity(tableEntity);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void UpdateEntity(TableClient client, string partitionKey, string rowKey)
        {
            PersonEntity personEntity = client.GetEntity<PersonEntity>(partitionKey, rowKey);
            personEntity.FirstName = "Warsus";
            client.UpdateEntity(personEntity, ETag.All, TableUpdateMode.Replace);
        }

        static void GetPersonEntities(TableClient client, string partitionKey)
        {
            // Using TableEntity from Azure.Data.Tables
            Pageable<TableEntity> oDataQueryEntities = client.Query<TableEntity>(filter: TableClient.CreateQueryFilter($"PartitionKey eq {partitionKey}"));
            foreach (TableEntity entity in oDataQueryEntities)
            {
                Console.WriteLine($"TableEntity : {entity.GetString("PartitionKey")}:{entity.GetString("RowKey")}, {entity.GetString("FirstName")}, {entity.GetString("LastName")}");
            }

            // Using custom entity
            Pageable<PersonEntity> oDataQueryEntities2 = client.Query<PersonEntity>(filter: TableClient.CreateQueryFilter($"PartitionKey eq {partitionKey}"));
            foreach (PersonEntity entity in oDataQueryEntities2)
            {
                Console.WriteLine($"CustomEntity : {entity.PartitionKey}:{entity.RowKey}, {entity.FirstName}, {entity.LastName}");
            }

            // Using LINQ
            Pageable<PersonEntity> linqEntities = client.Query<PersonEntity>(customer => customer.PartitionKey == "User");
            foreach (PersonEntity entity in linqEntities)
            {
                Console.WriteLine($"LINQ : {entity.RowKey} {entity.PartitionKey}");
            }
        }

        static void DeleteEntity(TableClient client, string partitionKey, string rowKey)
        {
            Response response = client.DeleteEntity(partitionKey, rowKey);
        }
    }
}
